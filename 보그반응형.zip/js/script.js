$(".burger").click(
    function(){
        $(this).toggleClass("on");
        $(".popup_nav").toggleClass("on");
    }
);